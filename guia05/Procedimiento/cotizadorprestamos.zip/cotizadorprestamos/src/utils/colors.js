export default{
 PRIMARY_COLOR:'#0098D3',
 PRIMARY_COLOR_DARk: '#006691',
}